import JS
from tkinter import ttk
class Library:
    def showBooks(self):
        self.Book_Table=ttk.Treeview(DataFrameRight,columns=('Book ID','Book Title','Author'),yscrollcommand=scroll_y.set)
        scroll_y.pack(side=RIGHT,fill=Y)
        scroll_y.config(command=self.Book_Table.yview)
        self.Book_Table.pack()
        self.Book_Table.heading('Book ID',text='Book Id')
        self.Book_Table.heading('Book Title',text='Book Name')
        self.Book_Table.heading('Author',text='Author')
        self.Book_Table['show']='headings'
        self.Book_Table.bind('<ButtonRelease-1>',self.get_cursor)
        self.Addbk=Button(DataFrameRight,text='Fetch Books',font=('arial',12,'bold'),command=self.fetch,bd=4,width=20)
        self.Addbk.pack()


    def populateBooktable(self):
        booklist = JS.getBookList()
        for book in booklist:
            self.Book_Table.insert('',END,values=book)
            
    
