import pandas as pd
import JS


#df = pd.read_csv(r'D:\Downloads\books1.csv')
#booklist = df[['id','title', 'subtitle', 'authors', 'categories','description', 'published_year', 'average_rating','ratings_count']]
booklist = JS.getBookList()
#id = booklist[3]
#print(booklist)
list = JS.books_suggestion(0)
print('Recomended books are ')
for book in list:
    print(book['title'])



#print(booklist)


    
    
